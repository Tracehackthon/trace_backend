import test from 'node:test'
import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { exchangeZhihuCode } from '../zhihu.mjs'
import { readOAuthCallback } from '../src/oauth-callback.js'

const input = { appId: 'test-app', appKey: 'test-secret', redirectUri: 'https://trace.example/callback', code: 'test-code' }
const reply = (body, status = 200) => new Response(JSON.stringify(body), { status })

test('HTTP 200 token business errors abort before fetching user data', async () => {
  let calls = 0
  await assert.rejects(exchangeZhihuCode({ ...input, request: async () => { calls++; return reply({ code: 401, data: 'Access token is not valid' }) } }), /401/)
  assert.equal(calls, 1)
})

test('missing token is rejected', async () => {
  await assert.rejects(exchangeZhihuCode({ ...input, request: async () => reply({}) }), /access_token/)
})

test('HTTP 200 user business errors do not create a user', async () => {
  let calls = 0
  await assert.rejects(exchangeZhihuCode({ ...input, request: async () => ++calls === 1 ? reply({ access_token: 'test-token' }) : reply({ code: 403, data: 'API Access Deny' }) }), /403/)
})

test('missing user ID is rejected', async () => {
  let calls = 0
  await assert.rejects(exchangeZhihuCode({ ...input, request: async () => ++calls === 1 ? reply({ access_token: 'test-token' }) : reply({ fullname: 'Test' }) }), /用户 ID/)
})

test('valid exchange uses configured callback and only returns public profile', async () => {
  const result = await exchangeZhihuCode({ ...input, request: async (url, options) => {
    assert.equal(options.redirect, 'error')
    assert.ok(options.signal)
    if (url.endsWith('/access_token')) {
      assert.equal(options.headers['content-type'], 'application/x-www-form-urlencoded')
      const form = new URLSearchParams(options.body)
      assert.equal(form.get('redirect_uri'), input.redirectUri)
      assert.equal(form.get('app_id'), input.appId)
      assert.equal(form.get('app_key'), input.appKey)
      assert.equal(form.get('code'), input.code)
      assert.equal(form.get('grant_type'), 'authorization_code')
      return reply({ access_token: 'test-token' })
    }
    assert.equal(options.headers.authorization, 'Bearer test-token')
    return reply({ uid: 123, fullname: 'Test', email: 'private@example.test' })
  } })
  assert.equal(result.uid, '123')
  assert.equal(result.provider, 'zhihu')
  assert.equal(result.email, undefined)
  assert.equal(result.access_token, undefined)
})

test('transport failures redact upstream exceptions', async () => {
  await assert.rejects(exchangeZhihuCode({ ...input, request: async () => { throw new Error('test-secret') } }), error => !error.message.includes('test-secret') && error.message.includes('超时'))
})

async function startServer(t, config = {}) {
  const child = spawn(process.execPath, ['server.mjs'], {
    cwd: fileURLToPath(new URL('../', import.meta.url)),
    env: { ...process.env, TRACE_DESKTOP_PORT: '0', TRACE_AUTH_DEMO: '', ZHIHU_APP_ID: '', ZHIHU_APP_KEY: '', ZHIHU_REDIRECT_URI: '', NODE_ENV: 'test', ...config },
    stdio: ['ignore', 'pipe', 'pipe'],
  })
  t.after(() => new Promise(resolve => {
    if (child.exitCode !== null || child.signalCode !== null) return resolve()
    child.once('exit', resolve)
    child.kill()
  }))
  return new Promise((resolve, reject) => {
    let output = ''
    const timeout = setTimeout(() => reject(new Error('Test server startup timed out')), 10000)
    child.once('error', error => { clearTimeout(timeout); reject(error) })
    child.once('exit', code => { clearTimeout(timeout); reject(new Error(`Test server exited: ${code}`)) })
    child.stdout.on('data', chunk => {
      output += chunk
      const match = output.match(/http:\/\/127\.0\.0\.1:\d+/)
      if (match) { clearTimeout(timeout); resolve(match[0]) }
    })
  })
}

test('missing credentials fail closed instead of silently logging in a demo user', async t => {
  const base = await startServer(t)
  assert.equal((await fetch(`${base}/api/auth/zhihu/url`)).status, 503)
  assert.equal((await fetch(`${base}/api/auth/zhihu/demo?state=fake`)).status, 404)
  assert.equal((await fetch(`${base}/api/auth/me`)).status, 401)
})

test('real mode fixes callback, disables demo routes, rejects demo code and reused state', async t => {
  const base = await startServer(t, { ZHIHU_APP_ID: input.appId, ZHIHU_APP_KEY: input.appKey, ZHIHU_REDIRECT_URI: input.redirectUri, TRACE_AUTH_DEMO: 'true' })
  const authResponse = await fetch(`${base}/api/auth/zhihu/url?redirect_uri=https://other.example/callback`)
  const cookie = authResponse.headers.get('set-cookie').split(';')[0]
  const auth = await authResponse.json()
  const target = new URL(auth.authorize_url)
  assert.equal(auth.demo, false)
  assert.equal(target.origin, 'https://openapi.zhihu.com')
  assert.equal(target.searchParams.get('redirect_uri'), input.redirectUri)
  assert.equal((await fetch(`${base}/api/auth/zhihu/demo?state=${auth.state}`)).status, 404)
  const submit = body => fetch(`${base}/api/auth/zhihu/callback`, { method: 'POST', headers: { 'content-type': 'application/json', cookie }, body: JSON.stringify(body) })
  assert.equal((await submit({ state: auth.state, code: 'trace-demo-code' })).status, 400)
  assert.equal((await submit({ state: auth.state, code: 'test-code' })).status, 400)
  assert.equal((await fetch(`${base}/api/auth/me`)).status, 401)
})

test('parses the official authorization_code field and keeps legacy callbacks compatible', () => {
  assert.deepEqual(readOAuthCallback('?authorization_code=test-code&state=nonce'), { code: 'test-code', state: 'nonce', error: null })
  assert.equal(readOAuthCallback('?code=old-code&state=nonce').code, 'old-code')
  assert.equal(readOAuthCallback('', '#authorization_code=hash-code&state=nonce').code, 'hash-code')
  assert.equal(readOAuthCallback('?authorization_code=test-code').state, null)
  assert.equal(readOAuthCallback('').code, null)
  assert.throws(() => readOAuthCallback('?authorization_code=one&code=two'), /冲突/)
  assert.throws(() => readOAuthCallback('?state=one', '#state=two'), /冲突/)
})

test('binds each login to its initiating browser and still requires a returned state', async t => {
  const base = await startServer(t, { TRACE_AUTH_DEMO: 'true' })
  const authResponse = await fetch(`${base}/api/auth/zhihu/url`)
  const cookieHeader = authResponse.headers.get('set-cookie')
  assert.match(cookieHeader, /HttpOnly/)
  assert.match(cookieHeader, /SameSite=Lax/)
  const cookie = cookieHeader.split(';')[0]
  const auth = await authResponse.json()
  const body = readOAuthCallback(`?authorization_code=trace-demo-code&state=${auth.state}`)
  const submit = (payload, browserCookie = cookie) => fetch(`${base}/api/auth/zhihu/callback`, {
    method: 'POST', headers: { 'content-type': 'application/json', cookie: browserCookie }, body: JSON.stringify(payload),
  })
  assert.equal((await submit(body, '')).status, 400)
  assert.equal((await submit(body, 'trace_oauth_browser=another-browser')).status, 400)
  assert.equal((await submit({ code: body.code })).status, 400)
  const success = await submit(body)
  assert.equal(success.status, 200)
  const sessionCookie = success.headers.get('set-cookie').split(';')[0]
  assert.equal((await fetch(`${base}/api/auth/me`, { headers: { cookie: sessionCookie } })).status, 200)
  assert.equal((await submit(body)).status, 400)
})
