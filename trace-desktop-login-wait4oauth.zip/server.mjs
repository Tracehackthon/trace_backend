import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import crypto from 'node:crypto'
import { exchangeZhihuCode } from './zhihu.mjs'

const root = path.dirname(fileURLToPath(import.meta.url))
const requestedPort = Number(process.env.TRACE_DESKTOP_PORT ?? '4173')
const port = Number.isInteger(requestedPort) && requestedPort >= 0 ? requestedPort : 4173
const mimeTypes = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.png', 'image/png'],
  ['.svg', 'image/svg+xml'],
  ['.json', 'application/json; charset=utf-8'],
])

const zhihuAppId = process.env.ZHIHU_APP_ID || ''
const zhihuAppKey = process.env.ZHIHU_APP_KEY || ''
const zhihuRedirectUri = process.env.ZHIHU_REDIRECT_URI || `http://127.0.0.1:${port}/callback`
const realAuth = Boolean(zhihuAppId && zhihuAppKey && process.env.ZHIHU_REDIRECT_URI)
const demoEnabled = process.env.TRACE_AUTH_DEMO === 'true' && process.env.NODE_ENV !== 'production' && !zhihuAppId && !zhihuAppKey
const oauthStates = new Map()
const sessions = new Map()
const users = new Map()
const demoUser = { uid: 'trace-demo', fullname: 'Trace 访客', headline: '本地开发预览账号', avatar_path: '', provider: 'zhihu' }

function json(response, status, body, headers = {}) {
  response.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers })
  response.end(JSON.stringify(body))
}

function parseCookies(request) {
  return Object.fromEntries((request.headers.cookie || '').split(';').filter(Boolean).map((part) => {
    const [key, ...value] = part.trim().split('=')
    return [key, decodeURIComponent(value.join('='))]
  }))
}

function requestBody(request) {
  return new Promise((resolve, reject) => {
    let body = ''
    request.on('data', (chunk) => { body += chunk })
    request.on('end', () => { try { resolve(body ? JSON.parse(body) : {}) } catch (error) { reject(error) } })
    request.on('error', reject)
  })
}

function upsertUser(profile) {
  const key = `${profile.provider || 'zhihu'}:${profile.uid}`
  const previous = users.get(key)
  const user = { id: previous?.id || crypto.randomUUID(), ...previous, ...profile, createdAt: previous?.createdAt || new Date().toISOString(), lastLoginAt: new Date().toISOString() }
  users.set(key, user)
  return user
}

function issueSession(user) {
  const id = crypto.randomBytes(24).toString('hex')
  sessions.set(id, { user, createdAt: Date.now() })
  return id
}

function redirect(response, location) {
  response.writeHead(302, { location, 'cache-control': 'no-store' })
  response.end()
}

async function handleApi(request, response, url) {
  if (url.pathname === '/api/auth/me' && request.method === 'GET') {
    const session = sessions.get(parseCookies(request).trace_session)
    return json(response, session ? 200 : 401, session ? { user: session.user } : { error: 'unauthorized' })
  }
  if (url.pathname === '/api/auth/logout' && request.method === 'POST') {
    sessions.delete(parseCookies(request).trace_session)
    return json(response, 200, { ok: true }, { 'set-cookie': 'trace_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0' })
  }
  if (url.pathname === '/api/auth/zhihu/url' && request.method === 'GET') {
    if (!realAuth && !demoEnabled) return json(response, 503, { error: '知乎登录尚未配置完成，请联系 TRACE 管理员核对 OAuth App ID、App Key 和登记的回调地址' })
    for (const [key, entry] of oauthStates) if (Date.now() - entry.createdAt > 10 * 60 * 1000) oauthStates.delete(key)
    const state = crypto.randomUUID()
    oauthStates.set(state, { createdAt: Date.now(), redirectUri: zhihuRedirectUri, mode: demoEnabled ? 'demo' : 'zhihu' })
    const redirectUri = oauthStates.get(state).redirectUri
    const authorizeUrl = realAuth
      ? `https://openapi.zhihu.com/authorize?redirect_uri=${encodeURIComponent(redirectUri)}&app_id=${encodeURIComponent(zhihuAppId)}&response_type=code&state=${encodeURIComponent(state)}`
      : `/api/auth/zhihu/demo?state=${encodeURIComponent(state)}`
    return json(response, 200, { authorize_url: authorizeUrl, state, demo: demoEnabled })
  }
  if (url.pathname === '/api/auth/zhihu/demo' && request.method === 'GET') {
    if (!demoEnabled) return json(response, 404, { error: '本地演示授权未启用' })
    const state = url.searchParams.get('state')
    if (!state || !oauthStates.has(state)) return redirect(response, '/?auth_error=invalid_state')
    return redirect(response, `/callback?code=trace-demo-code&state=${encodeURIComponent(state)}`)
  }
  if (url.pathname === '/api/auth/zhihu/callback' && request.method === 'POST') {
    let body
    try { body = await requestBody(request) } catch { return json(response, 400, { error: 'Invalid JSON' }) }
    const stateRecord = oauthStates.get(body.state)
    if (!stateRecord || Date.now() - stateRecord.createdAt > 10 * 60 * 1000) return json(response, 400, { error: '授权链接已失效，请返回 TRACE 重新点击登录；请勿收藏或重复使用授权链接' })
    oauthStates.delete(body.state)
    if (body.redirect_uri && body.redirect_uri !== stateRecord.redirectUri) return json(response, 400, { error: 'redirect_uri 不匹配' })
    if (typeof body.code !== 'string' || !body.code.trim()) return json(response, 400, { error: '缺少有效授权码，请重新发起登录' })
    if (body.code === 'trace-demo-code' && stateRecord.mode !== 'demo') return json(response, 400, { error: '真实知乎登录不能使用演示授权码' })
    try {
      let user
      if (demoEnabled && stateRecord.mode === 'demo' && body.code === 'trace-demo-code') user = demoUser
      else {
        if (!realAuth) return json(response, 400, { error: '本地演示不接受知乎授权码' })
        user = await exchangeZhihuCode({ appId: zhihuAppId, appKey: zhihuAppKey, redirectUri: stateRecord.redirectUri, code: body.code })
      }
      const account = upsertUser(user)
      const sessionId = issueSession(account)
      return json(response, 200, { user: account }, { 'set-cookie': `trace_session=${encodeURIComponent(sessionId)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${60 * 60 * 24 * 30}` })
    } catch (error) { return json(response, 502, { error: error.message || '知乎授权失败' }) }
  }
  return false
}

function resolveAsset(url = '/') {
  const pathname = decodeURIComponent(new URL(url, 'http://127.0.0.1').pathname)
  const relative = pathname === '/' || pathname === '/callback' ? 'index.html' : pathname.replace(/^\/+/, '')
  const absolute = path.resolve(root, relative)
  return absolute === root || absolute.startsWith(`${root}${path.sep}`) ? absolute : null
}

const server = http.createServer(async (request, response) => {
  const url = new URL(request.url, `http://127.0.0.1:${port}`)
  if (url.pathname.startsWith('/api/')) {
    const handled = await handleApi(request, response, url)
    if (handled !== false) return
  }
  const asset = resolveAsset(request.url)
  if (!asset || !fs.existsSync(asset) || !fs.statSync(asset).isFile()) {
    response.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' })
    response.end('Not found')
    return
  }
  response.writeHead(200, {
    'content-type': mimeTypes.get(path.extname(asset).toLowerCase()) ?? 'application/octet-stream',
    'cache-control': 'no-store',
  })
  fs.createReadStream(asset).pipe(response)
})

server.listen(port, '127.0.0.1', () => {
  console.log(`Trace Desktop Agent: http://127.0.0.1:${server.address().port}/`)
})

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    server.close(() => process.exit(0))
    server.closeAllConnections()
  })
}
