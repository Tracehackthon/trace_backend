export async function exchangeZhihuCode({ appId, appKey, redirectUri, code, request = fetch }) {
  async function readResponse(url, options, stage) {
    let response
    try {
      response = await request(url, { ...options, redirect: 'error', signal: AbortSignal.timeout(15000) })
    } catch {
      throw new Error(`知乎${stage}请求失败或超时，请重新发起登录`)
    }
    let body
    try { body = await response.json() } catch { throw new Error(`知乎${stage}返回格式异常`) }
    if (!response.ok || body?.error || (body?.code !== undefined && ![0, 200].includes(Number(body.code)))) {
      const status = Number(body?.code) || response.status
      throw new Error(`知乎${stage}失败（${status}），请核对 OAuth 应用凭据、权限和登记的回调地址`)
    }
    return body
  }

  const token = await readResponse('https://openapi.zhihu.com/access_token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ app_id: appId, app_key: appKey, grant_type: 'authorization_code', redirect_uri: redirectUri, code }).toString(),
  }, '授权码交换')
  if (typeof token?.access_token !== 'string' || !token.access_token) throw new Error('知乎未返回有效 access_token，请核对 OAuth 应用配置')

  const profile = await readResponse('https://openapi.zhihu.com/user', {
    headers: { authorization: `Bearer ${token.access_token}` },
  }, '用户信息获取')
  if (!['string', 'number'].includes(typeof profile?.uid) || !String(profile.uid).trim()) throw new Error('知乎未返回有效用户 ID，无法创建 TRACE 账号')
  return { uid: String(profile.uid), fullname: String(profile.fullname || '知乎用户'), headline: String(profile.headline || ''), avatar_path: String(profile.avatar_path || ''), provider: 'zhihu' }
}
