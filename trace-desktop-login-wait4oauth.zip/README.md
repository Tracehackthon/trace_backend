# Trace Desktop Agent（UI Prototype）

## 本地界面更新

- 登录页改为浅绿色河流全屏场景，背景由用户提供的参考图提取并重新合成。
- 路径的四个节点带错峰呼吸光晕和扩散光圈，文字已加粗；页尾居中展示“认知涌现，点亮Trace飞鸟效应”，窄屏独占一行。减少动态效果设置同时禁用节点动画。
- 水面折射与四只飞鸟由 `src/river-scene.js` 渲染；近处飞鸟避开登录内容和底部文字。右上角内容已移除，系统开启减少动态效果时默认静止，页面隐藏时暂停绘制。
- 登录页样式为 `src/auth.css`，场景素材为 `public/scenes/river.png`。知乎 OAuth 配置与未配置时的错误提示沿用原有实现。

- 白绿色工作区：记忆列表、深度讨论、认知工厂。
- 记忆列表提供 DeepSeek、Kimi、知乎、Codex 来源标识、搜索和筛选。
- 对话中的“形成候选”进入认知工厂，支持来源回看、暂存回顾、确认采用及撤回。
- 桌宠输入可加入记忆列表，或新建深度讨论。
- 当前平台对话与已有置信度为示例数据。新候选置信度为“待评估”。
- 交互状态仅存于当前浏览器标签页的 sessionStorage；未接入平台账号、真实模型或长期记忆后端。

在此目录运行 `node server.mjs`，访问 `http://127.0.0.1:4173/`。请通过 HTTP 访问，不能直接双击 `index.html`。

## 知乎登录

登录页按附件实现了知乎 OAuth 2.0 Authorization Code Flow。尚未完成真实应用凭据和用户授权的端到端验证。必须提供知乎 OAuth 应用后台的 App ID、配套 App Key 和已登记的 redirect_uri；截图中的“绑定知乎账号”不能作为 App ID 的依据。缺少配置会返回明确错误，不会自动登录演示账号。

```powershell
$env:ZHIHU_APP_ID = 'your-app-id'
$env:ZHIHU_APP_KEY = 'your-app-key'
$env:ZHIHU_REDIRECT_URI = 'https://yourdomain.com/callback'
node server.mjs
```

服务端校验有效期十分钟的一次性 `state`，使用授权码换取 token，再请求知乎用户信息，并检查 HTTP 状态及响应体内的业务错误码。浏览器只保存 HttpOnly 会话 ID Cookie；知乎 token 在服务端请求用户信息后不再保存，也不返回给前端。用户记录和会话当前仅保存在进程内存中，重启会清空；未实现持久化注册数据库。生产环境仍需要 HTTPS、持久化存储、绑定浏览器的 CSRF 校验及完整会话生命周期管理。

排查跳转时，先区分知乎登录页和授权确认页：未登录知乎的浏览器会先到 `/signin?next=...authorize...`。这表明授权入口已被访问，不代表 App ID 已获验证。先在同一个浏览器完成知乎登录，再由知乎验证应用并展示授权确认。授权链接中的 `state` 不可收藏后长期复用，请从 TRACE 重新发起。`127.0.0.1` 只指向浏览器所在电脑，不能作为其他设备访问 TRACE 的公网地址；对外部署应登记实际的 HTTPS 域名和固定回调路径。

仅测试 UI 时，可在非生产环境显式设置 `TRACE_AUTH_DEMO=true`，同时清空知乎 App ID / App Key。真实模式完全禁用演示授权。运行 `npm test` 检查错误处理和演示隔离，运行 `npm run build` 检查语法。
入口脚本为 `src/workspace.js`，样式为 `src/workspace.css`，示例数据为 `src/data.js`。
原始 `src/main.js` 与 `src/style.css` 保留作下载版本参考，当前入口不再加载它们。

本地资源：Lucide 0.468.0（ISC，许可见 `public/vendor/lucide-LICENSE`）；DeepSeek、Kimi、OpenAI 图形来自 LobeHub Icons；知乎标志来自 Simple Icons。平台名称及标志归各自权利人所有。

`apps/desktop/` 现在包含可运行的桌面尺寸 Web 原型，用来承接 DeepSeek Harness 中的“继续讨论”。当前版本聚焦产品闭环：接收一条观察、进入深度讨论、查看现场与待回答问题，并在会话内形成候选状态。

```powershell
pnpm --filter @trace/app-desktop dev
```

默认地址：`http://127.0.0.1:4173/`。

Harness 可以通过查询参数带入现场：

```text
/?from=deepseek-harness&observationId=...&text=...&status=...&source=...
```

当前边界：

- UI 与交互为可演示原型，讨论回复使用明确标识的 Mock Agent；
- 不直接读写 SQLite / JSONL；
- 不自动保存用户输入；
- Electron / Tauri / Wails 壳和真实模型调用仍未接入；
- 后续通过 product application / MCP / SDK 接入 Trace runtime。

已经确定的集成方向：

```text
desktop renderer / main process
          ↓ explicit product application / MCP / SDK
Trace runtime（project-local .trace/state/trace.sqlite）
          ↓
core protocol / data / storage
```

桌面端与 Codex 必须共享同一项目本地 `.trace/`，不会另建隐蔽状态库。可复用的用户动作是：状态、来源安全摘要、候选 review、proposal、adopt、receipt；renderer 不得直接读写 SQLite/JSONL，也不得将输入框 prompt 自动入库。

进入真实 Agent 阶段前，仍需以 Change Set 固化 desktop event schema、版本与 replay fixture；将文件、网络和认知源权限转成可见且可撤销的确认；通过多次使用、恢复、backup/restore、不同 profile 的端到端验证后，才可标记 desktop runtime 已实现。
